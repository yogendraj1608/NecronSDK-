Pre-Requisites:-
1.Must Install Bun
2.Must Install Node.js

To Run:- 
open terminal in same folder
1.)Run this command to execute the main function "bun run nec-aut'js".
2.)Run"bun run bsvdk.js" as they are used to sign transactions and control access to funds.
3.) "bsvdk.js" is Converts the randomly generated private key into its WIF format. WIF is a standardized format that represents private keys in a shorter, more readable form. It’s commonly used for importing and exporting private keys between wallets.


Thank You,
 Feel free to give feedback.


-Team 5(CyberGuard Innovations)